# 料金表: モバイルアプリケーション開発 (iOS/Android)

## 1. 基本開発費用
- シングルOS (iOS or Android): 6,000,000 JPY〜
- クロスプラットフォーム (Flutter/React Native): 8,000,000 JPY〜

## 2. オプション費用
- プッシュ通知実装: 500,000 JPY
- 決済機能 (Stripe/Apple Pay): 1,000,000 JPY
- オフライン同期機能: 1,500,000 JPY
