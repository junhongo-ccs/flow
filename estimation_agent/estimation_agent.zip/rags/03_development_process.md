# 開発プロセス規約

## 段階的開発
1. 要件定義 (Requirement Definition)
2. デザイン・プロトタイピング (Design)
3. 開発・実装 (Development)
4. テスト・QA (Testing)
5. リリース・移行 (Release)

各段階で見積もりの見直しが必要。
初期段階の見積もりは ±20% の変動を許容すること。
